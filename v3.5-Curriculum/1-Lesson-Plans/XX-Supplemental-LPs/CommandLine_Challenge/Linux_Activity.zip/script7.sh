#!/bin/bash


q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
qq="${tey:32:1}"
abc="asd 9 asdakasstream editorasd9a sdakas d"
sa="${abc:13:13}"
tpy="382654565434323456765488775544335588765454987382993371184567235528239231231230123812398120938123"
rc="pOxWcNmLuJiKdEfGhYtRsMnBvCxZaQpOIUyTREsdFghJkLmjNHbgVFcxZsDFgHjKlMnbV"
xp="cat activity.log | sed 's/WRONG_PASSWORD/LOGIN_REJECTED/'"
him="7283674872637829372839273829381193842923002389320323"
ttj="dj872349286472934230492139134820398420394823948203957230947230948234sdjjoshudasksndmichaeljoneshdjas"
cr="${him:30:3}"
puyh="7513823829932073845602ef670568fa02aaad7a15393a24f6c5b0f032d32ea9347d53b684344e99994a7215528239231231230123812398120938123"
aavk="${puyh:14:8}"
pk_i=6
tty="382382993377384567235528239231231230123812398120938123"
rv="${tty:20:2}"
uyh="754713823829932073abgitlabamazonyahoolinkedincnnabcnbc5602ef670568fa02aaad7a15393a24f6c5b0f032d32ea9347d53b684344e99994a7215528239231231230123812398120938123"
uuyh="751dj2382993jd9sdf79shdf6723hksdfsdf2073845602ef670568fa02aaad7a15393a24f6c5b0f032d32ea9347d53b684344e99994a7215528239231231230123812398120938123"
xuyh="754713823829jd9sdf79shdf6723hksdfsdf932073abgitlabamazonyahoolinkedincnnabcnbc5602ef670568fa02aa3923123123012381239812093"
aaxb="${xuyh:12:24}"
az="${uyh:1:2}"
aaza="${uyh:20:6}"
aaaz="${uyh:2:2}"
atj="hashybcryptalgohasingsha23hashregex45"
axb="${atj:5:6}"
ttj="djas374h12el234234loshjasdk434534245234asduiasthomasjulesdhaskasddkaakernighandkasduiihasdjjoshudasksndmichaeljoneshdjas"
aabx="${ttj:8:2}"
jj="${ttj:49:9}"
ttr="382382993377384567234528239231231230123812398120938123"
mm="${ttr:20:1}"
pp="${tpy:53:2}"
tey="382382993377384567235528239231255530123812398120938123"
uty="382382993387384567235528239231231230123812398120938123"
uu="${uty:10:1}"
vk="${rc:6:15}"
rk="${rc:3:12}"
dlc="sed '1,5d' activity.log"
uk_i=20
uk_l=24
q3="${q3_string:$q3_i:$q3_l}"
hk="${rc:uk_i:uk_l}"
pk="${rc:pk_i:uk_l}"
sk_i=15
q5_l=2
rk_i=9
sk_l=12
sk="${rc:sk_i:sk_l}"
q1_string="abcde564140874lmnopqr5645wxyz1234567890abc674521407845mnopqrstuvwxyz1234567890"
q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q4_i=9
q4_l=3
q3_l=3
q5_string="9ijklm3op436qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q5_i=10
q4="${q4_string:$q4_i:$q4_l}"
q5="${q5_string:$q5_i:$q5_l}"
q3="${q3_string:$q3_i:$q3_l}"

# Blank line
echo

# Function to prompt the user and check the answer
check_answer() {
    local question="$1"
    local correct_answer="$2"
    local hint="$3"

    while true; do
        read -p "$question " user_input
        if [[ "$user_input" == "$correct_answer" ]]; then
            echo "Correct!"
            break
        else
            echo "Incorrect. $hint"
        fi
    done
}

# Blank line
echo

# Prompt the user to enter the secret key
read -p "Enter the secret key you obtained from completing the last activity: " uk

# Blank line
echo

# Check if the entered key matches the expected value
if [[ "$uk" == "$aavk" ]]; then
    echo "Congrats for completing activity 6, This is the final Activity!!"
    echo "In this next activity, you are tasked with analyzing a list of URLs"
    echo "There is an internal employee under investigation, your IT team pulled a list of URLs the employee accessed"
    echo "Your legal team needs to get some data about the websites visited by the employee"
    echo "The file with thie information is called URL_list.txt"
    echo "For all of these activities, you will be be using a combination of the commands in all the previous activities"

    # Blank line
    echo

    # Question 1: Count of .com websites?
    check_answer "How many unique .com websites were accessed?" "$aaaz"

    # Blank line
    echo

    # Question 2: Ordering of domains
    hint="Hint: Only list the domain without the subdomain and the tld, for example if you found www.linkedin.com, the answer would be: linkedin"
    check_answer "Create a list of only the top unique primary domains (remove the subdomain and the tld), organize it in alphabetical order, and list the 21st domain?" "$aaza"  "$hint"

    # Blank line
    echo

    # Question 3: Image file count
    hint="Hint: You may have to do a little research on extensions of image files"
    check_answer "How many image files were accessed?" "$aabx" "$hint"

    # Blank line
    echo

    # Question 4: Delimiting by a charachter
    hint="Hint: Once you find the domain from the list, find the complete url from URL_list.txt, and access that webpage"
    check_answer "From the list you created on question #2,  find the 31st domain on the list, Visit the original URL and enter in the code found!" "$aaxb" "$hint"




else
    echo "Incorrect key entered. Please go back and finish the previous activity to get the secret key and come back."
    exit 1
fi


    echo

#  Congrats message!
echo "Congratulations you have completed the Linux challenge!"

