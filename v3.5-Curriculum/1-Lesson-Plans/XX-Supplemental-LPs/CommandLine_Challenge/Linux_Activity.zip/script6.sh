#!/bin/bash


q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
qq="${tey:32:1}"
abc="asd 9 asdakasstream editorasd9a sdakas d"
sa="${abc:13:13}"
tpy="382654565434323456765488775544335588765454987382993371184567235528239231231230123812398120938123"
rc="pOxWcNmLuJiKdEfGhYtRsMnBvCxZaQpOIUyTREsdFghJkLmjNHbgVFcxZsDFgHjKlMnbV"
xp="cat activity.log | sed 's/WRONG_PASSWORD/LOGIN_REJECTED/'"
him="7283674872637829372839273829381193842923002389320323"
ttj="dj872349286472934230492139134820398420394823948203957230947230948234sdjjoshudasksndmichaeljoneshdjas"
cr="${him:30:3}"
pk_i=6
tty="382382993377384567235528239231231230123812398120938123"
rv="${tty:20:2}"
uyh="7513823829932073845602ef670568fa02aaad7a15393a24f6c5b0f032d32ea9347d53b684344e99994a7215528239231231230123812398120938123"
puyh="7513823829932073845602ef670568fa02aaad7a15393a24f6c5b0f032d32ea9347d53b684344e99994a7215528239231231230123812398120938123"
aavk="${puyh:14:8}"
az="${uyh:1:2}"
aaz="${uyh:12:2}"
aza="${uyh:20:64}"
abx="${ttj:23:4}"
atj="hashybcryptalgohasingsha23hashregex45"
axb="${atj:5:6}"
ttj="djasdyuhelloshjasdkasduiasthomasjulesdhaskasddkaakernighandkasduiihasdjjoshudasksndmichaeljoneshdjas"
jj="${ttj:49:9}"
ttr="382382993377384567234528239231231230123812398120938123"
mm="${ttr:20:1}"
pp="${tpy:53:2}"
tey="382382993377384567235528239231255530123812398120938123"
uty="382382993387384567235528239231231230123812398120938123"
uu="${uty:10:1}"
vk="${rc:6:15}"
rk="${rc:3:12}"
dlc="sed '1,5d' activity.log"
uk_i=20
uk_l=24
q3="${q3_string:$q3_i:$q3_l}"
hk="${rc:uk_i:uk_l}"
pk="${rc:pk_i:uk_l}"
sk_i=15
q5_l=2
rk_i=9
sk_l=12
sk="${rc:sk_i:sk_l}"
q1_string="abcde564140874lmnopqr5645wxyz1234567890abc674521407845mnopqrstuvwxyz1234567890"
q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q4_i=9
q4_l=3
q3_l=3
q5_string="9ijklm3op436qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q5_i=10
q4="${q4_string:$q4_i:$q4_l}"
q5="${q5_string:$q5_i:$q5_l}"
q3="${q3_string:$q3_i:$q3_l}"

# Blank line
echo

# Function to prompt the user and check the answer
check_answer() {
    local question="$1"
    local correct_answer="$2"
    local hint="$3"

    while true; do
        read -p "$question " user_input
        if [[ "$user_input" == "$correct_answer" ]]; then
            echo "Correct!"
            break
        else
            echo "Incorrect. $hint"
        fi
    done
}

# Blank line
echo


# Prompt the user to enter the secret key
read -p "Enter the secret key you obtained from completing activity 5: " uk

# Blank line
echo

# Check if the entered key matches the expected value
if [[ "$uk" == "$vk" ]]; then
    echo "Congrats for completing activity 5!!"
    echo "In this next activity, you are tasked with a challenging activity"
    echo "Your organization had an employee file that was accessed by a malicious actor"
    echo "Your legal team needs to understand what information was potentially exposed"
    echo "The file that was breached is called employee_table.csv"
    echo "For all of these activities, you will be primarily researching new commands"

    # Blank line
    echo

    # Question 1: Count of hashes?
    check_answer "How many employees data were exposed?" "$aaz"

    # Blank line
    echo

    # Question 2: Diff Question
    check_answer "What is the sha256 value of the file?" "$aza"

    # Blank line
    echo

    # Question 3: Figuring out what was changed with diff
    hint="Hint: You may have to use the cut command to accomplish this task, along with a wc command"
    check_answer 'Your legal team only needs a file that has the fields of name and Password_hash with the header row. After running the script to create this file, what is the charachter count of the file?' "$abx" "$hint"

    # Blank line
    echo

    # Question 4: Delimiting by a charachter
    hint="Hint: Grab one hash and do some online research about how to determine the hash type"
    check_answer "Your legal team wants to know what type of hash has been created for the hashes, can you figure that out?" "$axb" "$hint"




else
    echo "Incorrect key entered. Please go back and finish the previous activity to get the secret key and come back."
    exit 1
fi


    echo

# Provide the secret key for activity 4
echo "Here is your secret key for the final activity: $aavk"

