#!/bin/bash


echo "$esk"

# Prompt the user for their name
read -p "What is your name? " user_name
sleep 2
echo " "
echo "Welcome $user_name, this first activity is just a review of basic terminal commands,"
echo "and to see how today's activity will work. Once you complete the activity,"
echo "you will be given a key, and this key will be used to run the next script"
echo " "

# Function to provide feedback and check command correctness
check_command() {
    local command_name="$1"
    local correct_response="$2"
    local user_input="$3"

    # Convert user input to lowercase for case-insensitive comparison
    user_input_lower=$(echo "$user_input" | tr '[:upper:]' '[:lower:]')

    if [[ "$user_input_lower" == "$command_name" ]]; then
        # Provide feedback for correct command
        echo -e "Great Job, $user_name! $correct_response\n"
        return 0
    elif [[ "$user_input_lower" == "exit" ]]; then
        # Exit the script if the user wants to quit
        echo "Exiting the script. Goodbye $user_name!"
        exit 0
    else
        # Provide a hint for incorrect commands
        echo "Incorrect command, $user_name. Please try again or type 'exit' to quit."
        return 1
    fi
}

# Question 1: Working directory
while true; do
    read -p "$user_name, what is the command to check your working directory? " user_input
    check_command "pwd" "That is the correct command!" "$user_input" && break
    sleep 4
    echo -e "\n"
done

ask=$(echo "sdf8sdfsdfkjsdf6" | base64)
es7=$(echo "sdf8sdfs766sdfkf6" | base64)
eok=$(echo "sdf8s886sdfdfkjsdf6" )
esl=$(echo "sdf823jksdf8sdfkjsdf6" | base64)
jsk=$(echo "sdf8s888ddddfkjsdf6" | base64)
esk=$(echo "sMnBvCxZaQpOIUyTREsdFghJ")
psk=$(echo "sdf8sdfsdf86kjsdf6" | base64)
msk=$(echo "sdasdasdf8sdfksdf6" | base64)






# Question 2: List files and directories
while true; do
    read -p "$user_name, what is the command to list out files and directories from this directory? " user_input
    check_command "ls" " " "$user_input" && break
    sleep 4
    echo -e "\n"
done

# Question 3: Create an empty file
while true; do
    read -p "$user_name, what is the command to create an empty file named 'example.txt'? " user_input
    check_command "touch example.txt" "With the command you would of created a file called 'example.txt'." "$user_input" && break
    sleep 4
    echo -e "\n"
done

# Question 4: View file contents
while true; do
    read -p "$user_name, what is the command to view the contents of 'example.txt'? (Hint: use the command that also concatenates) " user_input
    check_command "cat example.txt" " " "$user_input" && break
    sleep 4
    echo -e "\n"
done

# Question 5: Remove file
while true; do
    read -p "$user_name, what is the command to remove 'example.txt'? " user_input
    check_command "rm example.txt" "'example.txt' would be successfully removed." "$user_input" && break
    sleep 4
    echo -e "\n"
done

#


# Give the user the encoded secret key
echo "Congratulations $user_name! You've completed all the questions." 
echo "Here is your secret key: $esk, now run the next script "script2.sh", be sure to enter in your secret key"
