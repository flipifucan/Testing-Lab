#!/bin/bash


q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
abc="asd 9 asdakasstream editorasd9a sdakas d"
sa="${abc:13:13}"
rc="pOxWcNmLuJiKdEfGhYtRsMnBvCxZaQpOIUyTREsdFghJkLmjNHbgVFcxZsDFgHjKlMnbV"
xp="cat activity.log | sed 's/WRONG_PASSWORD/LOGIN_REJECTED/'"
him="7283674872637829372839273829381143842923002389320323"
cr="${him:30:3}"
pk_i=6
tty="382382993377384567235528239231231230123812398120938123"
rv="${tty:20:2}"
dlc="sed '1,5d' activity.log"
uk_i=20
uk_l=24
q3="${q3_string:$q3_i:$q3_l}"
hk="${rc:uk_i:uk_l}"
pk="${rc:pk_i:uk_l}"
sk_i=15
q5_l=2
sk_l=12
sk="${rc:sk_i:sk_l}"
q1_string="abcde564140874lmnopqr5645wxyz1234567890abc674521407845mnopqrstuvwxyz1234567890"
q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q4_i=9
q4_l=3
q3_l=3
q5_string="9ijklm3op436qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q5_i=10
q4="${q4_string:$q4_i:$q4_l}"
q5="${q5_string:$q5_i:$q5_l}"
q3="${q3_string:$q3_i:$q3_l}"

# Blank line
echo

# Function to prompt the user and check the answer
check_answer() {
    local question="$1"
    local correct_answer="$2"
    local hint="$3"

    while true; do
        read -p "$question " user_input
        if [[ "$user_input" == "$correct_answer" ]]; then
            echo "Correct!"
            break
        else
            echo "Incorrect. $hint"
        fi
    done
}

# Blank line
echo


# Prompt the user to enter the secret key
read -p "Enter the secret key you obtained from completing activity 2: " uk

# Blank line
echo

sleep 1

# Check if the entered key matches the expected value
if [[ "$uk" == "$sk" ]]; then
    echo "Congrats for completing activity 2."
    echo "In this next activity, you are tasked with"
    echo "analyzing an Activity Log File called activity.log."
    echo "Open this file up in another tab, or another gitbash session, and answer the following questions to get the next secret key."
    echo "For all of these activities, you will be primarily using the sed command, be sure to look at the manual!"

    # Blank line
    echo

    # Question 1: What does SED stand for (lower case)?
    check_answer "What does SED stand for (lower case)?" "$sa"

    # Blank line
    echo

    # Question 2: what is the command to replace "WRONG_PASSWORD" with "LOGIN_REJECTED"?
    check_answer "What is the command to replace 'WRONG_PASSWORD' with 'LOGIN_REJECTED'? Begin your command with 'cat activity.log':" "$xp"

    # Blank line
    echo

    # Question 3: Run the command and output it to a new file, now count the records in the new file that contain LOGIN_REJECTED
    hint="Hint: You can use wc to count lines"
    check_answer "Run the command and output it to a new file, now what is the count of records in the new file that contain LOGIN_REJECTED?" "$cr" "$hint"

    # Blank line
    echo

    # Question 4: Research and run the sed command to print out the 99th line in the activity.log file, what is the number that comes up after rv: on that line?
    hint="Hint: You can use sed to print a specific line number."
    check_answer "Research and run the sed command to print out the 99th line in the activity.log file, what is the number that comes up after rv: on that line?" "$rv" "$hint"

else
    echo "Incorrect key entered. Please go back and finish the previous script to get the secret key and come back."
    exit 1
fi


    echo

# Provide the secret key for activity 4
echo "Here is your secret key for the next activity: $pk"

