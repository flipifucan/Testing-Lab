#!/bin/bash

rc="pOxWcNmLuJiKdEfGhYtRsMnBvCxZaQpOIUyTREsdFghJkLmjNHbgVFcxZsDFgHjKlMnbV"
uk_i=20
uk_l=24
q3="${q3_string:$q3_i:$q3_l}"
hk="${rc:uk_i:uk_l}"
sk_i=15
q5_l=2
sk_l=12
sk="${rc:sk_i:sk_l}"
q1_string="abcde564140874lmnopqr5645wxyz1234567890abc674521407845mnopqrstuvwxyz1234567890"
q1_i=47
q1_l=3
q1="${q1_string:$q1_i:$q1_l}"
q2_string="abcdefgh4ijklmnopqrstuvwxyz1234567890abcdefgh4ijklmnopqrstuvwxyz1234567890"
q2_i=30
q2_l=1
q2="${q2_string:$q2_i:$q2_l}"
q3_string="9ijklm3op4qrs0tuv124wx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q3_i=17
q4_string="9ijklm3op1194qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q4_i=9
q4_l=3
q3_l=3
q5_string="9ijklm3op436qrs0tuvwx7yz1ABCD8EFGHIJK2LMNOPQRS5TUVWXYZ"
q5_i=10
q4="${q4_string:$q4_i:$q4_l}"
q5="${q5_string:$q5_i:$q5_l}"
q3="${q3_string:$q3_i:$q3_l}"


# Blank line
echo

# Function to prompt the user and check the answer
check_answer() {
    local question="$1"
    local correct_answer="$2"
    local hint="$3"

    while true; do
        read -p "$question " user_input
        if [[ "$user_input" == "$correct_answer" ]]; then
            echo "Correct!"
            break
        else
            echo "Incorrect. $hint"
        fi
    done
}

# Blank line
echo

# Prompt the user to enter the secret key
read -p "Enter the secret key you obtained from completing activity 1: " uk

# Blank line
echo

sleep 2

# Check if the entered key matches the expected value
if [[ "$uk" == "$hk" ]]; then
    echo "Congrats for completing activity 1."
    echo "In this second activity, you are tasked with analyzing an apache log file." 
    echo "Your organization has just noticed suspicious activity on its website,"
    echo "and you are tasked with analyzing the logs to look for evidence" 
    echo "that can help your company choose a mitigation strategy."
    echo "Your file is called apache.log," 
    echo "Open this file up in another tab, or another gitbash session, and answer the following questions to get the next secret key."
    echo "For all of these activities, you will be using the grep and wc command" 
else
    echo "Incorrect key entered. Please go back and finish script1 to get the secret key and come back."
    exit 1
fi

# Blank line
echo

# Question 1: How many lines are in the log file?
check_answer "How many lines are in the log file?" "$q1"

# Blank line
echo

# Question 2: How many POST requests are in the log file?
check_answer "How many POST requests are in the log file?" "$q2"

# Blank line
echo

# Question 3: How many records are GET requests that are not accessing a file that contains the name 'logo'?
hint="Hint: Use the man page to see how to exclude items in your search."
check_answer "How many records are GET requests that are not accessing a file that contains the name 'logo'?" "$q3" "$hint"

# Blank line
echo

# Question 4: What is the line number of the log record that has a GET request accessing "secret_banner.jpg"?
check_answer "What is the line number of the log record that has a GET request accessing 'secret_banner.jpg'?" "$q4"

# Blank line
echo

# Question 5: How many log records are in the log file accessing image files, specifically .jpg and .png?
check_answer "How many log records are in the log file accessing image files, specifically .jpg and .png?" "$q5"

# Blank line
echo

# Provide the secret key for activity 3
echo "Here is your secret key for activity 3: $sk"
